package Calcugeo;

public class formaGeo {
    private String cor;


    formaGeo(String cor){
        this.cor = cor;
    }

    public double calcularPerimetro(){
        System.out.println("invalido");
        return 0.0;
    }

    public double calculoArea(){
        System.out.println("invalido");
        return 0.0;
    }

    public double calcularVolume(){
        System.out.println("invalido");
        return 0.0;
    }

}
